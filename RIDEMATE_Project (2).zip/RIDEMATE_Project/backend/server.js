const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

let rides = [];

app.get("/rides", (req, res) => {
  res.json(rides);
});

app.post("/rides", (req, res) => {
  const { source, destination, seats } = req.body;

  const ride = {
    id: Date.now(),
    source,
    destination,
    seats
  };

  rides.push(ride);

  res.json({
    message: "Ride Added Successfully",
    ride
  });
});

app.listen(3000, () => {
  console.log("RIDEMATE running on http://localhost:3000");
});