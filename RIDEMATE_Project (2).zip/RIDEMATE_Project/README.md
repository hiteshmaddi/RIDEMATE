
# RIDEMATE

Full-stack ride sharing application.

## Features
- User Registration/Login
- Post Ride
- View Available Rides
- Book Ride
- MySQL Database
- Node.js + Express Backend

## Setup
1. Create MySQL database.
2. Run schema.sql.
3. Update DB credentials in backend/server.js.
4. npm install
5. npm start
