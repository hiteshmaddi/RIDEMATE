const rideList = document.getElementById("rideList");
const count = document.getElementById("count");

let rides =
JSON.parse(localStorage.getItem("rides")) || [];

function saveRides(){
localStorage.setItem(
"rides",
JSON.stringify(rides)
);
}

function updateCount(){
count.innerText = rides.length;
}

function renderRide(ride,index){

const card = document.createElement("div");

card.className = "ride-card";

card.innerHTML = `

<h5>
${ride.source} ➜ ${ride.destination}
</h5>

<p>
<strong>Driver:</strong>
${ride.driver}
</p>

<p>
<strong>Seats:</strong>
${ride.seats}
</p>

<p>
<strong>Price:</strong>
₹${ride.price}
</p>

<button class="btn btn-success me-2 book-btn">
Book Ride
</button>

<button class="btn btn-danger delete-btn">
Delete
</button>

`;

card.querySelector(".book-btn")
.addEventListener("click",()=>{

const passenger =
prompt("Enter Passenger Name");

if(passenger){
alert(
`Ride booked successfully for ${passenger}`
);
}

});

card.querySelector(".delete-btn")
.addEventListener("click",()=>{

rides.splice(index,1);

saveRides();

location.reload();

});

rideList.appendChild(card);

}

rides.forEach((ride,index)=>{
renderRide(ride,index);
});

updateCount();

document
.getElementById("rideForm")
.addEventListener("submit",async(e)=>{

e.preventDefault();

const ride = {

driver:
document.getElementById("driver").value,

source:
document.getElementById("source").value,

destination:
document.getElementById("destination").value,

seats:
document.getElementById("seats").value,

price:
document.getElementById("price").value

};

try{

await fetch(
"http://localhost:3000/rides",
{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify(ride)
}
);

rides.push(ride);

saveRides();

location.reload();

}
catch{

alert("Server not running");

}

});

document
.getElementById("search")
.addEventListener("keyup",function(){

const value =
this.value.toLowerCase();

const cards =
document.querySelectorAll(".ride-card");

cards.forEach(card=>{

card.style.display =
card.innerText
.toLowerCase()
.includes(value)
? "block"
: "none";

});

});